Pierce Buzhardt
CPSC 3520
SDE3

On my honor I have neither given nor received aid on this
exam
SIGN: Pierce Buzhardt

FILES:

cmeans.pro: contains the functions written in prolog to execute the cmeans algorithm

readme.txt: this file. Details the other files, and assures that I have not given or received help on this project.

sde3.log: a log that shows 3 uses of each of the required predicates.