Pierce Buzhardt
CPSC 3520
October 31, 2018
SDE2

Pledge:
On my honor I have neither given nor received aid on this
exam.

Or this sde. Because, well, exam...

FILES INCLUDED IN ARCHIVE

readme.txt: this file, which lists the content and titles of the other files in the archive, and the integrity pledge.

cmean.caml: the required functions to be implemented, implemented

pbuzhar-sde2.log: log file of 2 sample uses of each required function and a log of 5 sample uses of the cmean function.